<table class="table table-bordered table-condensed">
    <tr>
        <td style="width: 180px">
            <img style="width: 150px;" src="<?=$em_logo?>">
        </td>

        <td>
            <b>Empresa: </b> <?=$em_nome?> <br>
            <b>CNPJ: </b> <?=$em_cnpj?><br>
            <b>Responsável: </b> <?=$res_nome?><br>
            <b>Data Inicial: </b> <?=$dataInicial?> <b>Data Final: </b> <?=$dataFinal?>

        </td>
    </tr>
</table>



